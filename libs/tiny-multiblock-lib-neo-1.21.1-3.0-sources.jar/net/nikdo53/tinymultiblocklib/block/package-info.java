@ParametersAreNonnullByDefault
package net.nikdo53.tinymultiblocklib.block;

import javax.annotation.ParametersAreNonnullByDefault;