@ParametersAreNonnullByDefault
package net.nikdo53.tinymultiblocklib.blockentities;

import javax.annotation.ParametersAreNonnullByDefault;